# Vježba 6 - Razor Pages + pretraživanje, filtriranje, sortiranje

> **Verzija:** .NET 10 (LTS).

## Što ova vježba radi

Web aplikacija napravljena s **Razor Pages** (ne MVC kao u vježbi 5) koja koristi **isti API iz vježbe 4**. Profesor izričito traži Razor Pages u 6. vježbi.

Dodane funkcionalnosti naspram vježbe 5:
- **Pretraživanje** po imenu, prezimenu, OIB-u, MBO-u (jedno tekst polje pretražuje sve)
- **Filtriranje**: checkbox "samo aktivni"
- **Sortiranje**: klikom na zaglavlje stupca u tablici. Drugi klik na isti stupac obrne smjer (▲/▼). Stupci po kojima se može sortirati: **Ime, Prezime, OIB, MBO, Datum primanja, Datum otpusta** (točno ono što profesor traži).

## Struktura (Razor Pages)

```
PacijentiRP.sln
├── PacijentiRP/
│   ├── Pages/
│   │   ├── Index.cshtml             ← /  (redirect na popis)
│   │   ├── Pacijenti/
│   │   │   ├── Index.cshtml         ← /Pacijenti (popis + search + sort)
│   │   │   ├── Index.cshtml.cs      ← PageModel s logikom
│   │   │   ├── Novi.cshtml          ← /Pacijenti/Novi
│   │   │   ├── Novi.cshtml.cs
│   │   │   ├── Uredi.cshtml         ← /Pacijenti/Uredi/{id}
│   │   │   └── Uredi.cshtml.cs
│   │   ├── Shared/_Layout.cshtml
│   │   └── _ViewImports.cshtml, _ViewStart.cshtml
│   ├── Servisi/ApiKlijent.cs
│   ├── Program.cs
│   └── wwwroot/css/site.css
└── PacijentiShared/                 ← isti DTO-i
```

## Razor Pages vs. MVC - razlika

| MVC (vježba 5) | Razor Pages (vježba 6) |
| --- | --- |
| Jedan kontroler za više stranica | Svaka stranica ima svoj PageModel (code-behind) |
| `Views/Pacijenti/Index.cshtml` | `Pages/Pacijenti/Index.cshtml` + `Index.cshtml.cs` |
| Akcijska metoda vraća `View(model)` | Stranica radi s `OnGet/OnPost` metodama |
| Routing: `/Controller/Action/Id` | Routing: po datotečnoj strukturi |
| `[BindProperty]` na metodi | `[BindProperty]` na propertyju |

## Kako pokrenuti

### 1) Pokreni API iz vježbe 4 (mora biti aktivan)
Otvori `Vjezba4_API/PacijentiSustav.sln` u jednom Visual Studio prozoru, F5. API ide na `https://localhost:7100`.

### 2) Otvori Razor Pages projekt
`Vjezba6_RazorPages/PacijentiRP.sln` → F5 → browser na `https://localhost:7300/Pacijenti`.

## Kako koristiti

- **Pretraživanje**: upiši dio imena/prezimena/OIB-a/MBO-a u textbox i klikni "Primijeni" (ili pritisni Enter).
- **Filter**: čekiraj "Samo aktivni" - prikazuju se samo oni koji nemaju datum otpusta.
- **Sortiranje**: klikni na zaglavlje stupca u tablici. Strjelica (▲/▼) pokazuje smjer.
- **Resetiraj**: gumb "Resetiraj" miče sve filtere.
- Sortiranje, pretraživanje i filter se **kombiniraju** i čuvaju u URL-u (možeš podijeliti link s rezultatima).

## Koncepti iz vaših primjera

| Primjer | Gdje |
| --- | --- |
| `AsynchronousMembers.cs` | Svi `OnGetAsync`/`OnPostAsync` handleri |
| `ObjectAndCollectionInitializer.cs` | `new PacijentDto { Ime = ..., Prezime = ... }` u handlerima |
| `NullableValueTypes.cs` | `DateTime? DatumOtpusta`, `int?` za opcionalni id |
| `Iterators.cs` (LINQ Where/OrderBy) | Pretraživanje i sortiranje u `Index.cshtml.cs` |
| `NameofOperator.cs` | (Bonus tip - umjesto magic stringa za sort) Možeš koristiti `nameof(PacijentDto.Ime)` umjesto `"Ime"` |
| `StringInterpolation.cs` | URL gradnja s `$"?{key}={value}"` |
| `ExpressionBodiedMembers` | `=> await ...` u ApiKlijentu |

## Bonus - kako bi izgledalo s API filterom

Trenutno cijela lista dolazi s API-ja pa se filtrira u PageModel-u (jednostavnije za vježbu). U pravoj produkciji bi prosljedili `?search=&sortBy=` direktno na API, a API bi filtriranje radio kroz `IQueryable` u kontroleru. Ako profesoru treba ta varijanta, samo se proširi `GET /api/pacijenti` u vježbi 4 s parametrima — ApiKlijent ostane isti, samo dobije nove opcionalne parametre.
