using PacijentiRP.Servisi;

var builder = WebApplication.CreateBuilder(args);

// KLJUČNA RAZLIKA U ODNOSU NA VJEŽBU 5:
// AddRazorPages umjesto AddControllersWithViews.
builder.Services.AddRazorPages();

builder.Services.AddHttpClient<ApiKlijent>(c =>
{
    c.BaseAddress = new Uri(builder.Configuration["ApiBaseUrl"]
                           ?? "https://localhost:7100/");
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// I ovdje: MapRazorPages umjesto MapControllerRoute
app.MapRazorPages();

app.Run();
