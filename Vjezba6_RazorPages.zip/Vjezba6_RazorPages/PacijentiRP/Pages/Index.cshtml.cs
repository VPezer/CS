using Microsoft.AspNetCore.Mvc.RazorPages;
namespace PacijentiRP.Pages { public class IndexModel : PageModel { } }
