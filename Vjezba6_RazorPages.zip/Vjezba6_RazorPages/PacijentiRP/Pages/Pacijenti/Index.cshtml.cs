using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PacijentiRP.Servisi;
using PacijentiShared;

namespace PacijentiRP.Pages.Pacijenti
{
    // Razor Pages = stil gdje svaka stranica ima vlastiti PageModel (code-behind),
    // umjesto da jedan kontroler servisira više stranica (kao u MVC-u iz vježbe 5).
    //
    // OnGet/OnGetAsync se zove kad korisnik otvori stranicu (GET).
    // OnPost/OnPostAsync se zove na submit forme (POST).
    public class IndexModel : PageModel
    {
        private readonly ApiKlijent _api;

        public IndexModel(ApiKlijent api) { _api = api; }

        // ---- Parametri iz URL-a (querystring) ----
        // [BindProperty(SupportsGet = true)] = automatski popunjava iz ?search=...&sortBy=...
        [BindProperty(SupportsGet = true)] public string Search { get; set; }
        [BindProperty(SupportsGet = true)] public string SortBy { get; set; } = "Prezime";
        [BindProperty(SupportsGet = true)] public bool SortDesc { get; set; }
        [BindProperty(SupportsGet = true)] public bool SamoAktivni { get; set; }

        // Lista koja se prikazuje u tablici
        public List<PacijentDto> Pacijenti { get; private set; } = new();

        // Što su dozvoljeni stupci po kojima profesor traži sortiranje/pretraživanje
        public static readonly string[] DozvoljenaSortiranja = new[]
            { "Ime", "Prezime", "OIB", "MBO", "DatumPrimanja", "DatumOtpusta" };

        public async Task OnGetAsync()
        {
            // 1. Dohvati sve s API-ja
            var svi = await _api.DohvatiSve();

            // 2. PRETRAŽIVANJE - traži po više polja istovremeno
            //    (ime, prezime, OIB, MBO)
            if (!string.IsNullOrWhiteSpace(Search))
            {
                var s = Search.Trim().ToLower();
                svi = svi.Where(p =>
                    (p.Ime ?? "").ToLower().Contains(s) ||
                    (p.Prezime ?? "").ToLower().Contains(s) ||
                    (p.OIB ?? "").Contains(s) ||
                    (p.MBO ?? "").Contains(s)
                ).ToList();
            }

            // 3. FILTRIRANJE - samo aktivni
            if (SamoAktivni)
                svi = svi.Where(p => p.DatumOtpusta == null).ToList();

            // 4. SORTIRANJE - po dozvoljenom stupcu, asc ili desc.
            //    Koristimo LINQ OrderBy s expression za odabir ključa.
            svi = SortBy switch
            {
                "Ime"            => Sortiraj(svi, p => p.Ime),
                "Prezime"        => Sortiraj(svi, p => p.Prezime),
                "OIB"            => Sortiraj(svi, p => p.OIB),
                "MBO"            => Sortiraj(svi, p => p.MBO),
                "DatumPrimanja"  => Sortiraj(svi, p => p.DatumPrimanja),
                "DatumOtpusta"   => Sortiraj(svi, p => p.DatumOtpusta ?? DateTime.MaxValue),
                _                => svi
            };

            Pacijenti = svi;
        }

        // Generička pomoćna metoda za sortiranje - vraća listu sortiranu uzlazno ili silazno
        private List<PacijentDto> Sortiraj<TKey>(
            List<PacijentDto> izvor, Func<PacijentDto, TKey> kljuc)
        {
            return SortDesc
                ? izvor.OrderByDescending(kljuc).ToList()
                : izvor.OrderBy(kljuc).ToList();
        }

        // OTPUST iz tablice - poseban handler "Otpust"
        // u XAML-u/Razoru se vidi kao asp-page-handler="Otpust"
        public async Task<IActionResult> OnPostOtpustAsync(int id)
        {
            await _api.Otpusti(id);
            TempData["Poruka"] = "Pacijent otpušten.";
            return RedirectToPage(new
            {
                Search,
                SortBy,
                SortDesc,
                SamoAktivni
            });
        }

        // Pomoćna metoda koja vraća link s preokrenutim sortom (za klik na header stupca)
        public string LinkZaSortiranje(string stupac)
        {
            bool obrniSmjer = SortBy == stupac ? !SortDesc : false;
            var ruta = new Dictionary<string, string>
            {
                ["Search"] = Search,
                ["SortBy"] = stupac,
                ["SortDesc"] = obrniSmjer.ToString().ToLower(),
                ["SamoAktivni"] = SamoAktivni.ToString().ToLower()
            };
            var qs = string.Join("&", ruta.Where(kv => !string.IsNullOrEmpty(kv.Value))
                .Select(kv => $"{kv.Key}={Uri.EscapeDataString(kv.Value)}"));
            return "?" + qs;
        }

        // Strjelica u headeru
        public string IndikatorSorta(string stupac)
        {
            if (SortBy != stupac) return "";
            return SortDesc ? " ▼" : " ▲";
        }
    }
}
