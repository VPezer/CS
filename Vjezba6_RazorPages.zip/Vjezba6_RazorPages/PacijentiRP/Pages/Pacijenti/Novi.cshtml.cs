using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PacijentiRP.Servisi;
using PacijentiShared;

namespace PacijentiRP.Pages.Pacijenti
{
    public class NoviModel : PageModel
    {
        private readonly ApiKlijent _api;
        public NoviModel(ApiKlijent api) { _api = api; }

        // Ugnijezda klasa za podatke forme - mogli bismo i zasebni VM koristiti,
        // ali ovo je čistiji "Razor Pages style".
        public class UnosForma
        {
            [Required(ErrorMessage = "Ime je obavezno")]
            public string Ime { get; set; }

            [Required(ErrorMessage = "Prezime je obavezno")]
            public string Prezime { get; set; }

            [Required]
            [RegularExpression(@"^\d{11}$", ErrorMessage = "OIB mora biti 11 znamenki")]
            public string OIB { get; set; }

            [StringLength(9)]
            public string MBO { get; set; }

            [Required] public string Spol { get; set; } = "Musko";

            [Required, DataType(DataType.Date)]
            public DateTime DatumRodenja { get; set; } = DateTime.Today.AddYears(-30);

            [Required, DataType(DataType.Date)]
            public DateTime DatumPrimanja { get; set; } = DateTime.Today;

            [DataType(DataType.Date)]
            public DateTime? DatumOtpusta { get; set; }

            [Required(ErrorMessage = "Odaberite dijagnozu")]
            public string DijagnozaSifra { get; set; }
        }

        // BindProperty bez SupportsGet = samo za POST submit
        [BindProperty] public UnosForma Forma { get; set; } = new();
        public List<DijagnozaDto> Dijagnoze { get; private set; } = new();

        public async Task OnGetAsync()
        {
            Dijagnoze = await _api.DohvatiDijagnoze();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                Dijagnoze = await _api.DohvatiDijagnoze();
                return Page();
            }

            try
            {
                await _api.Dodaj(new PacijentDto
                {
                    Ime = Forma.Ime,
                    Prezime = Forma.Prezime,
                    OIB = Forma.OIB,
                    MBO = Forma.MBO,
                    Spol = Forma.Spol,
                    DatumRodenja = Forma.DatumRodenja,
                    DatumPrimanja = Forma.DatumPrimanja,
                    DatumOtpusta = Forma.DatumOtpusta,
                    DijagnozaSifra = Forma.DijagnozaSifra
                });

                TempData["Poruka"] = "Pacijent dodan.";
                return RedirectToPage("./Index");
            }
            catch (System.Net.Http.HttpRequestException ex) when (ex.Message.Contains("409"))
            {
                ModelState.AddModelError("Forma.OIB", "Pacijent s tim OIB-om već postoji.");
                Dijagnoze = await _api.DohvatiDijagnoze();
                return Page();
            }
        }
    }
}
