using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using PacijentiRP.Servisi;
using PacijentiShared;

namespace PacijentiRP.Pages.Pacijenti
{
    public class UrediModel : PageModel
    {
        private readonly ApiKlijent _api;
        public UrediModel(ApiKlijent api) { _api = api; }

        public class IzmjenaForma
        {
            public int Id { get; set; }

            [Required] public string Ime { get; set; }
            [Required] public string Prezime { get; set; }
            [Required, RegularExpression(@"^\d{11}$")] public string OIB { get; set; }
            [StringLength(9)] public string MBO { get; set; }
            [Required] public string Spol { get; set; }
            [Required, DataType(DataType.Date)] public DateTime DatumRodenja { get; set; }
            [Required, DataType(DataType.Date)] public DateTime DatumPrimanja { get; set; }
            [DataType(DataType.Date)] public DateTime? DatumOtpusta { get; set; }
            [Required] public string DijagnozaSifra { get; set; }
        }

        [BindProperty] public IzmjenaForma Forma { get; set; }
        public List<DijagnozaDto> Dijagnoze { get; private set; } = new();

        // GET /Pacijenti/Uredi?id=5  (Razor Pages koristi querystring po defaultu)
        public async Task<IActionResult> OnGetAsync(int id)
        {
            var p = await _api.Dohvati(id);
            if (p == null) return NotFound();

            Forma = new IzmjenaForma
            {
                Id = p.Id,
                Ime = p.Ime,
                Prezime = p.Prezime,
                OIB = p.OIB,
                MBO = p.MBO,
                Spol = p.Spol,
                DatumRodenja = p.DatumRodenja,
                DatumPrimanja = p.DatumPrimanja,
                DatumOtpusta = p.DatumOtpusta,
                DijagnozaSifra = p.DijagnozaSifra
            };
            Dijagnoze = await _api.DohvatiDijagnoze();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                Dijagnoze = await _api.DohvatiDijagnoze();
                return Page();
            }

            await _api.Izmijeni(Forma.Id, new PacijentDto
            {
                Id = Forma.Id,
                Ime = Forma.Ime,
                Prezime = Forma.Prezime,
                OIB = Forma.OIB,
                MBO = Forma.MBO,
                Spol = Forma.Spol,
                DatumRodenja = Forma.DatumRodenja,
                DatumPrimanja = Forma.DatumPrimanja,
                DatumOtpusta = Forma.DatumOtpusta,
                DijagnozaSifra = Forma.DijagnozaSifra
            });

            TempData["Poruka"] = "Promjene spremljene.";
            return RedirectToPage("./Index");
        }
    }
}
