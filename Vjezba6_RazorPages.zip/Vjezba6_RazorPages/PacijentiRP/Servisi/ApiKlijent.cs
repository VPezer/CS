using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using PacijentiShared;

namespace PacijentiRP.Servisi
{
    public class ApiKlijent
    {
        private readonly HttpClient _http;
        public ApiKlijent(HttpClient http) { _http = http; }

        public async Task<List<PacijentDto>> DohvatiSve()
        {
            // Cijela lista - filtriranje/sortiranje radimo lokalno u Razor Page-u
            // (jednostavnije za vježbu, profesor ne traži optimizaciju).
            return await _http.GetFromJsonAsync<List<PacijentDto>>("api/pacijenti");
        }

        public async Task<PacijentDto> Dohvati(int id)
            => await _http.GetFromJsonAsync<PacijentDto>($"api/pacijenti/{id}");

        public async Task<PacijentDto> Dodaj(PacijentDto dto)
        {
            var r = await _http.PostAsJsonAsync("api/pacijenti", dto);
            r.EnsureSuccessStatusCode();
            return await r.Content.ReadFromJsonAsync<PacijentDto>();
        }

        public async Task Izmijeni(int id, PacijentDto dto)
        {
            var r = await _http.PutAsJsonAsync($"api/pacijenti/{id}", dto);
            r.EnsureSuccessStatusCode();
        }

        public async Task Otpusti(int id)
        {
            var r = await _http.PostAsync($"api/pacijenti/{id}/otpust", null);
            r.EnsureSuccessStatusCode();
        }

        public async Task<List<DijagnozaDto>> DohvatiDijagnoze()
            => await _http.GetFromJsonAsync<List<DijagnozaDto>>("api/dijagnoze");
    }
}
