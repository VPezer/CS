namespace PacijentiWPF.Modeli
{
    // Klasa koja predstavlja jednu MKB-10 dijagnozu.
    // Koristimo auto-implemented properties (vidi primjer AutoImplementedProperties.cs)
    public class Dijagnoza
    {
        public string Sifra { get; set; }   // npr. "A00"
        public string Naziv { get; set; }   // npr. "Kolera"

        // Override ToString-a da bi se u ComboBoxu (i drugdje) prikazalo lijepo
        // kao npr. "A00 - Kolera" umjesto "PacijentiWPF.Modeli.Dijagnoza"
        public override string ToString()
        {
            return $"{Sifra} - {Naziv}";
        }
    }
}
