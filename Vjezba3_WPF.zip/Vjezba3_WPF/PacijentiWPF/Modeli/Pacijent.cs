using System;

namespace PacijentiWPF.Modeli
{
    // Glavna domenska klasa - jedan pacijent u bolničkom sustavu.
    //
    // Koristimo auto-properties iz vašeg primjera AutoImplementedProperties.cs.
    // DatumOtpusta je nullable (DateTime?) jer pacijent koji je još u bolnici
    // NEMA datum otpusta - to je upravo slučaj nullable value types
    // koji ste vidjeli u NullableValueTypes.cs.
    public class Pacijent
    {
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string OIB { get; set; }              // 11 znamenki
        public string MBO { get; set; }              // matični broj osiguranika, 9 znamenki
        public Spol Spol { get; set; }
        public DateTime DatumRodenja { get; set; }
        public DateTime DatumPrimanja { get; set; }
        public DateTime? DatumOtpusta { get; set; }  // null = još uvijek u bolnici
        public Dijagnoza Dijagnoza { get; set; }

        // Computed property - ne sprema se, računa se na licu mjesta.
        // Aktivan = nema datum otpusta.
        public bool Aktivan => DatumOtpusta == null;

        // Override ToString za debug ispis. Koristimo string interpolation
        // ($"...{var}...") iz vašeg primjera StringInterpolation.cs
        public override string ToString()
        {
            string status = Aktivan ? "aktivan" : "otpušten";
            return $"{Ime} {Prezime} ({OIB}) - {status}";
        }
    }
}
