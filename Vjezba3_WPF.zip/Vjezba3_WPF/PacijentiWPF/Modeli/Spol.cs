namespace PacijentiWPF.Modeli
{
    // Jednostavan enum - bolje od stringa "M"/"Z" jer je type-safe
    // (kompajler te upozori ako napišeš krivu vrijednost)
    public enum Spol
    {
        Musko,
        Zensko
    }
}
