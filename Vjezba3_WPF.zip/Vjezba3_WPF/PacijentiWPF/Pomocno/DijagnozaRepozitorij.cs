using System.Collections.Generic;
using PacijentiWPF.Modeli;

namespace PacijentiWPF.Pomocno
{
    // Statička klasa koja vraća fiksnu listu MKB-10 dijagnoza.
    // Profesor traži minimalno 10 šifri.
    //
    // U 4. vježbi ćemo OVO ZAMIJENITI pozivom API-ja - sada je dovoljna lokalna lista.
    // Koristimo Collection Initializer iz vašeg primjera ObjectAndCollectionInitializer.cs.
    public static class DijagnozaRepozitorij
    {
        public static List<Dijagnoza> DohvatiSve()
        {
            return new List<Dijagnoza>
            {
                new Dijagnoza { Sifra = "A00", Naziv = "Kolera" },
                new Dijagnoza { Sifra = "A01", Naziv = "Trbušni tifus i paratifus" },
                new Dijagnoza { Sifra = "B01", Naziv = "Vodene kozice (varicella)" },
                new Dijagnoza { Sifra = "E11", Naziv = "Dijabetes melitus tip 2" },
                new Dijagnoza { Sifra = "I10", Naziv = "Esencijalna hipertenzija" },
                new Dijagnoza { Sifra = "J18", Naziv = "Upala pluća, uzročnik nespecificiran" },
                new Dijagnoza { Sifra = "J45", Naziv = "Astma" },
                new Dijagnoza { Sifra = "K35", Naziv = "Akutni apendicitis" },
                new Dijagnoza { Sifra = "M54", Naziv = "Bol u leđima" },
                new Dijagnoza { Sifra = "R51", Naziv = "Glavobolja" }
            };
        }
    }
}
