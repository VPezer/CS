using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using PacijentiWPF.Modeli;
using PacijentiWPF.Pomocno;

namespace PacijentiWPF
{
    // Code-behind = C# kod koji "ide uz" MainWindow.xaml.
    // Klasa je partial (vidi vaš primjer PartialClasses.cs) - druga polovica
    // se automatski generira iz XAML-a.
    public partial class MainWindow : Window
    {
        // "Baza" pacijenata - in-memory lista. U 4. vježbi će ovo zamijeniti API.
        private readonly List<Pacijent> _pacijenti = new List<Pacijent>();

        public MainWindow()
        {
            InitializeComponent();        // Generirana metoda - povezuje XAML s ovom klasom
            UcitajDijagnoze();
            PostaviPocetneDatume();
            OsvjeziPrikaz();
        }

        private void UcitajDijagnoze()
        {
            // Napunimo ComboBox listom dijagnoza.
            cmbDijagnoza.ItemsSource = DijagnozaRepozitorij.DohvatiSve();
            cmbDijagnoza.SelectedIndex = 0;
        }

        private void PostaviPocetneDatume()
        {
            // Datum primanja default = danas, ostali ostaju prazni.
            dpDatumPrimanja.SelectedDate = DateTime.Today;
            dpDatumRodenja.SelectedDate = DateTime.Today.AddYears(-30);
        }

        // ---------------- GUMB SPREMI ----------------
        private void btnSpremi_Click(object sender, RoutedEventArgs e)
        {
            // 1. Validacija - ako nešto fali, prekidaj.
            if (string.IsNullOrWhiteSpace(txtIme.Text) ||
                string.IsNullOrWhiteSpace(txtPrezime.Text))
            {
                MessageBox.Show("Ime i prezime su obavezni.", "Greška",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (txtOIB.Text.Length != 11 || !txtOIB.Text.All(char.IsDigit))
            {
                MessageBox.Show("OIB mora imati točno 11 znamenki.", "Greška",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (dpDatumPrimanja.SelectedDate == null)
            {
                MessageBox.Show("Datum primanja je obavezan.", "Greška",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 2. Konstrukcija novog pacijenta pomoću Object Initializera
            //    (vidi vaš ObjectAndCollectionInitializer.cs).
            var pacijent = new Pacijent
            {
                Ime = txtIme.Text.Trim(),
                Prezime = txtPrezime.Text.Trim(),
                OIB = txtOIB.Text.Trim(),
                MBO = txtMBO.Text.Trim(),
                Spol = rbMusko.IsChecked == true ? Spol.Musko : Spol.Zensko,
                DatumRodenja = dpDatumRodenja.SelectedDate ?? DateTime.Today,
                DatumPrimanja = dpDatumPrimanja.SelectedDate.Value,
                DatumOtpusta = dpDatumOtpusta.SelectedDate,   // može biti null -> aktivan
                Dijagnoza = (Dijagnoza)cmbDijagnoza.SelectedItem
            };

            // Provjera duplikata po OIB-u
            if (_pacijenti.Any(p => p.OIB == pacijent.OIB))
            {
                MessageBox.Show("Pacijent s tim OIB-om već postoji.", "Greška",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _pacijenti.Add(pacijent);
            OsvjeziPrikaz();
            OcistiFormu();
        }

        // ---------------- GUMB OČISTI ----------------
        private void btnOcisti_Click(object sender, RoutedEventArgs e)
        {
            OcistiFormu();
        }

        // ---------------- GUMB OTPUSTI ----------------
        private void btnOtpusti_Click(object sender, RoutedEventArgs e)
        {
            // Uzmi odabranog pacijenta iz DataGrida i postavi mu datum otpusta na danas.
            if (dgPacijenti.SelectedItem is Pacijent odabrani)
            {
                if (odabrani.DatumOtpusta != null)
                {
                    MessageBox.Show("Pacijent je već otpušten.", "Info",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                odabrani.DatumOtpusta = DateTime.Today;
                OsvjeziPrikaz();
            }
            else
            {
                MessageBox.Show("Prvo odaberite pacijenta u tablici.", "Info",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        // ---------------- CHECKBOX (samo aktivni) ----------------
        private void chkSamoAktivni_Changed(object sender, RoutedEventArgs e)
        {
            OsvjeziPrikaz();
        }

        // ---------------- ODABIR REDA U TABLICI ----------------
        private void dgPacijenti_SelectionChanged(object sender,
            System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // Kad korisnik klikne na red, popuni formu njegovim podacima
            // (lijepa "edit-friendly" mogućnost).
            if (dgPacijenti.SelectedItem is Pacijent p)
            {
                txtIme.Text = p.Ime;
                txtPrezime.Text = p.Prezime;
                txtOIB.Text = p.OIB;
                txtMBO.Text = p.MBO;
                rbMusko.IsChecked = p.Spol == Spol.Musko;
                rbZensko.IsChecked = p.Spol == Spol.Zensko;
                dpDatumRodenja.SelectedDate = p.DatumRodenja;
                dpDatumPrimanja.SelectedDate = p.DatumPrimanja;
                dpDatumOtpusta.SelectedDate = p.DatumOtpusta;
                cmbDijagnoza.SelectedItem = cmbDijagnoza.Items
                    .Cast<Dijagnoza>()
                    .FirstOrDefault(d => d.Sifra == p.Dijagnoza?.Sifra);
            }
        }

        // ---------------- POMOĆNE METODE ----------------
        private void OsvjeziPrikaz()
        {
            // Filtriramo listu ovisno o checkboxu.
            IEnumerable<Pacijent> prikaz = _pacijenti;
            if (chkSamoAktivni.IsChecked == true)
                prikaz = prikaz.Where(p => p.Aktivan);

            // Refresh trika: prvo null pa onda lista (da DataGrid sigurno vidi promjenu).
            dgPacijenti.ItemsSource = null;
            dgPacijenti.ItemsSource = prikaz.ToList();
        }

        private void OcistiFormu()
        {
            txtIme.Clear();
            txtPrezime.Clear();
            txtOIB.Clear();
            txtMBO.Clear();
            rbMusko.IsChecked = true;
            PostaviPocetneDatume();
            dpDatumOtpusta.SelectedDate = null;
            cmbDijagnoza.SelectedIndex = 0;
        }
    }
}
