# Vježba 3 - WPF aplikacija "Evidencija pacijenata"

> **Verzija:** .NET 10 (LTS), Visual Studio 2022 17.12+ ili Visual Studio 2026.

## Što ova aplikacija radi

WPF aplikacija (Windows Presentation Foundation) koja omogućava:
- **Unos novog pacijenta** kroz formu s validacijom
- **Prikaz svih pacijenata** u tablici (DataGrid)
- **Filter "samo aktivni"** (oni koji nemaju datum otpusta)
- **Otpust pacijenta** klikom na red u tablici pa na gumb "Otpusti"
- **Različite kontrole ovisno o tipu podatka** (što profesor izričito traži):
  - `TextBox` za tekst (ime, prezime, OIB, MBO)
  - `DatePicker` za datume
  - `ComboBox` za odabir dijagnoze iz fiksnog popisa (10 MKB-10 šifri)
  - `RadioButton` za spol
  - `CheckBox` za filter

## Struktura projekta

```
PacijentiWPF/
├── Modeli/
│   ├── Pacijent.cs          ← glavna domenska klasa
│   ├── Dijagnoza.cs         ← MKB-10 dijagnoza (šifra + naziv)
│   └── Spol.cs              ← enum (Musko/Zensko)
├── Pomocno/
│   └── DijagnozaRepozitorij.cs   ← fiksna lista 10 dijagnoza
├── MainWindow.xaml          ← izgled (vizualni dio)
├── MainWindow.xaml.cs       ← logika (code-behind, eventi)
├── App.xaml                 ← ulazna točka aplikacije
└── PacijentiWPF.csproj      ← konfiguracija projekta
```

## Ključni koncepti koje smo iskoristili iz vaših primjera

| Primjer s faksa | Gdje se koristi |
| --- | --- |
| `AutoImplementedProperties.cs` | Sve klase u `Modeli/` koriste `{ get; set; }` |
| `ObjectAndCollectionInitializer.cs` | `new Pacijent { Ime = ..., Prezime = ... }` u `btnSpremi_Click` |
| `NullableValueTypes.cs` | `DateTime? DatumOtpusta` - pacijent koji je aktivan nema datum otpusta |
| `PartialClasses.cs` | `MainWindow` je partial klasa - druga polovica se automatski generira iz XAML-a |
| `StringInterpolation.cs` | `$"{Ime} {Prezime} ({OIB})"` u `ToString` metodama |
| `Expression-bodied-members` | `public bool Aktivan => DatumOtpusta == null;` |

## Kako pokrenuti

1. Otvoriti **Visual Studio 2022** (Community edition je besplatna)
2. **File → Open → Project/Solution → odabrati `PacijentiWPF.sln`**
3. Pritisnuti **F5** (Start Debugging) ili zeleni "play" gumb
4. Aplikacija se otvori - lijevo je forma, desno tablica

> Ako koristite stariji template "WPF App (.NET Framework)" iz uputa, samo otvori novi projekt iz tog templatea, obriši mu defaultni `MainWindow.xaml`/`xaml.cs` i kopiraj ove datoteke iz mape `Modeli/`, `Pomocno/` i `MainWindow.*` u taj projekt.

## Kako koristiti aplikaciju

1. **Unos**: ispuni polja lijevo → klik "Spremi" → pacijent se pojavljuje u tablici desno.
2. **Otpust**: klikni na red u tablici → klik "Otpusti" → datum otpusta se postavlja na danas, pacijent prestaje biti aktivan.
3. **Filter**: čekiraj "Prikaži samo aktivne pacijente" → tablica se filtrira.
4. **Validacije** koje aplikacija provodi:
   - Ime i prezime ne smiju biti prazni
   - OIB mora imati točno 11 znamenki
   - Datum primanja je obavezan
   - Ne mogu se dva pacijenta s istim OIB-om

## Što dolazi u vježbi 4

U sljedećoj vježbi ćemo:
- Maknuti `_pacijenti` listu (in-memory) i `DijagnozaRepozitorij`
- Umjesto njih napravit ćemo **REST API** koji čuva podatke u **SQL Server bazi**
- WPF aplikacija će preko `HttpClient`-a (vidi vaš `AsynchronousMembers.cs`) razgovarati s API-jem

Zato su modeli (`Pacijent`, `Dijagnoza`) izolirani u svoju mapu - lako ih je premjestiti/podijeliti sa serverom.
