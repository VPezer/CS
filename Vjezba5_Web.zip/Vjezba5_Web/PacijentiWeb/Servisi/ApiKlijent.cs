using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using PacijentiShared;

namespace PacijentiWeb.Servisi
{
    // Isti princip kao u WPF klijentu - sve metode su async.
    // U MVC-u se ApiKlijent registrira kao DI servis (vidi Program.cs).
    public class ApiKlijent
    {
        private readonly HttpClient _http;

        public ApiKlijent(HttpClient http)
        {
            _http = http;
        }

        public async Task<List<PacijentDto>> DohvatiSve(bool samoAktivni = false)
        {
            return await _http.GetFromJsonAsync<List<PacijentDto>>(
                $"api/pacijenti?samoAktivni={samoAktivni}");
        }

        public async Task<PacijentDto> Dohvati(int id)
        {
            return await _http.GetFromJsonAsync<PacijentDto>($"api/pacijenti/{id}");
        }

        public async Task<PacijentDto> Dodaj(PacijentDto dto)
        {
            var resp = await _http.PostAsJsonAsync("api/pacijenti", dto);
            resp.EnsureSuccessStatusCode();
            return await resp.Content.ReadFromJsonAsync<PacijentDto>();
        }

        public async Task Izmijeni(int id, PacijentDto dto)
        {
            var resp = await _http.PutAsJsonAsync($"api/pacijenti/{id}", dto);
            resp.EnsureSuccessStatusCode();
        }

        public async Task Otpusti(int id)
        {
            var resp = await _http.PostAsync($"api/pacijenti/{id}/otpust", null);
            resp.EnsureSuccessStatusCode();
        }

        public async Task<List<DijagnozaDto>> DohvatiDijagnoze()
        {
            return await _http.GetFromJsonAsync<List<DijagnozaDto>>("api/dijagnoze");
        }
    }
}
