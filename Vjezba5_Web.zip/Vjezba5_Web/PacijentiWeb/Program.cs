using PacijentiWeb.Servisi;

var builder = WebApplication.CreateBuilder(args);

// Registracija MVC + servisa
builder.Services.AddControllersWithViews();

// HttpClient za ApiKlijent - "Typed Client" pattern.
// BaseAddress čitamo iz appsettings.json -> ApiBaseUrl.
builder.Services.AddHttpClient<ApiKlijent>(c =>
{
    c.BaseAddress = new Uri(builder.Configuration["ApiBaseUrl"]
                           ?? "https://localhost:7100/");
});

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Klasično MVC routiranje: /{controller}/{action}/{id?}
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
