using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using PacijentiShared;
using PacijentiWeb.Servisi;
using PacijentiWeb.ViewModels;

namespace PacijentiWeb.Controllers
{
    // U MVC-u: Controller ima Action metode, svaka vraća View.
    // URL-ovi:  /Pacijenti           → Index
    //           /Pacijenti/Novi      → Novi (GET = forma, POST = spremanje)
    //           /Pacijenti/Uredi/5   → Uredi
    //           /Pacijenti/Otpust/5  → Otpust
    public class PacijentiController : Controller
    {
        private readonly ApiKlijent _api;

        public PacijentiController(ApiKlijent api)
        {
            _api = api;
        }

        // GET /Pacijenti?samoAktivni=true
        public async Task<IActionResult> Index(bool samoAktivni = false)
        {
            var lista = await _api.DohvatiSve(samoAktivni);
            ViewBag.SamoAktivni = samoAktivni;
            return View(lista);
        }

        // GET /Pacijenti/Novi
        public async Task<IActionResult> Novi()
        {
            var vm = new PacijentFormaVM
            {
                DostupneDijagnoze = await _api.DohvatiDijagnoze()
            };
            return View("Forma", vm);
        }

        // POST /Pacijenti/Novi
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Novi(PacijentFormaVM vm)
        {
            if (!ModelState.IsValid)
            {
                vm.DostupneDijagnoze = await _api.DohvatiDijagnoze();
                return View("Forma", vm);
            }

            var dto = VmUDto(vm);
            try
            {
                await _api.Dodaj(dto);
                TempData["Poruka"] = "Pacijent uspješno dodan.";
                return RedirectToAction(nameof(Index));
            }
            catch (System.Net.Http.HttpRequestException ex) when (ex.Message.Contains("409"))
            {
                ModelState.AddModelError(nameof(vm.OIB), "Pacijent s tim OIB-om već postoji.");
                vm.DostupneDijagnoze = await _api.DohvatiDijagnoze();
                return View("Forma", vm);
            }
        }

        // GET /Pacijenti/Uredi/5
        public async Task<IActionResult> Uredi(int id)
        {
            var p = await _api.Dohvati(id);
            if (p == null) return NotFound();

            var vm = new PacijentFormaVM
            {
                Id = p.Id,
                Ime = p.Ime,
                Prezime = p.Prezime,
                OIB = p.OIB,
                MBO = p.MBO,
                Spol = p.Spol,
                DatumRodenja = p.DatumRodenja,
                DatumPrimanja = p.DatumPrimanja,
                DatumOtpusta = p.DatumOtpusta,
                DijagnozaSifra = p.DijagnozaSifra,
                DostupneDijagnoze = await _api.DohvatiDijagnoze()
            };
            return View("Forma", vm);
        }

        // POST /Pacijenti/Uredi/5
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Uredi(int id, PacijentFormaVM vm)
        {
            if (!ModelState.IsValid)
            {
                vm.DostupneDijagnoze = await _api.DohvatiDijagnoze();
                return View("Forma", vm);
            }
            await _api.Izmijeni(id, VmUDto(vm));
            TempData["Poruka"] = "Pacijent uspješno izmijenjen.";
            return RedirectToAction(nameof(Index));
        }

        // POST /Pacijenti/Otpust/5  - jedan klik gumb, ne forma
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Otpust(int id)
        {
            try
            {
                await _api.Otpusti(id);
                TempData["Poruka"] = "Pacijent otpušten.";
            }
            catch (System.Exception ex)
            {
                TempData["Greska"] = "Greška: " + ex.Message;
            }
            return RedirectToAction(nameof(Index));
        }

        // Pomoćna - prevodi ViewModel u DTO koji ide na API
        private PacijentDto VmUDto(PacijentFormaVM vm) => new PacijentDto
        {
            Id = vm.Id ?? 0,
            Ime = vm.Ime,
            Prezime = vm.Prezime,
            OIB = vm.OIB,
            MBO = vm.MBO,
            Spol = vm.Spol,
            DatumRodenja = vm.DatumRodenja,
            DatumPrimanja = vm.DatumPrimanja,
            DatumOtpusta = vm.DatumOtpusta,
            DijagnozaSifra = vm.DijagnozaSifra
        };
    }
}
