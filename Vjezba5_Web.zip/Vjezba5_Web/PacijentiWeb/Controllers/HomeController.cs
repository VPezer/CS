using Microsoft.AspNetCore.Mvc;

namespace PacijentiWeb.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            // Početna stranica samo preusmjerava na popis pacijenata.
            return RedirectToAction("Index", "Pacijenti");
        }
    }
}
