using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using PacijentiShared;

namespace PacijentiWeb.ViewModels
{
    // ViewModel = klasa specifično napravljena za jedan View.
    // Razlika od DTO-a: ovdje stavljamo i listu dijagnoza (za <select>) i validacijske atribute.
    public class PacijentFormaVM
    {
        public int? Id { get; set; }   // null = novi, inače izmjena

        [Required(ErrorMessage = "Ime je obavezno")]
        public string Ime { get; set; }

        [Required(ErrorMessage = "Prezime je obavezno")]
        public string Prezime { get; set; }

        [Required, StringLength(11, MinimumLength = 11, ErrorMessage = "OIB mora imati 11 znamenki")]
        [RegularExpression(@"^\d{11}$", ErrorMessage = "OIB se sastoji samo od znamenki")]
        public string OIB { get; set; }

        [StringLength(9)]
        public string MBO { get; set; }

        [Required]
        public string Spol { get; set; } = "Musko";

        [Required]
        [DataType(DataType.Date)]
        public DateTime DatumRodenja { get; set; } = DateTime.Today.AddYears(-30);

        [Required]
        [DataType(DataType.Date)]
        public DateTime DatumPrimanja { get; set; } = DateTime.Today;

        [DataType(DataType.Date)]
        public DateTime? DatumOtpusta { get; set; }

        [Required(ErrorMessage = "Odaberite dijagnozu")]
        public string DijagnozaSifra { get; set; }

        // Lista koja se napuni iz API-ja i prosljeđuje u <select> element.
        public List<DijagnozaDto> DostupneDijagnoze { get; set; } = new();
    }
}
