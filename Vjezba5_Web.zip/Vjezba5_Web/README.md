# Vježba 5 - Web aplikacija (ASP.NET Core MVC)

> **Verzija:** .NET 10 (LTS).

## Što ova vježba radi

Web aplikacija u browseru koja **koristi isti API iz vježbe 4**. Sve funkcionalnosti koje profesor traži:

- **Unos pacijenta** (`/Pacijenti/Novi`)
- **Izmjena podataka pacijenta** (`/Pacijenti/Uredi/{id}`)
- **Otpust pacijenta** (gumb "Otpusti" u tablici)
- **Prikaz (ne)aktivnih pacijenata** (`/Pacijenti` + checkbox "Samo aktivni")

API se NE MIJENJA - samo se "spoji" na njega kao i WPF.

## Struktura

```
PacijentiWeb.sln
├── PacijentiWeb/          ← ASP.NET Core MVC aplikacija
│   ├── Controllers/       ← PacijentiController, HomeController
│   ├── Views/Pacijenti/   ← Index.cshtml, Forma.cshtml
│   ├── Views/Shared/      ← _Layout.cshtml
│   ├── ViewModels/        ← PacijentFormaVM
│   ├── Servisi/           ← ApiKlijent (poziva API iz vježbe 4)
│   └── Program.cs
└── PacijentiShared/       ← isti DTO-i kao u vježbi 4
```

## MVC pattern - što je što

| Dio | Uloga | Datoteka |
| --- | --- | --- |
| **M**odel | Podaci | `PacijentDto`, `PacijentFormaVM` |
| **V**iew | HTML predložak (Razor) | `Index.cshtml`, `Forma.cshtml` |
| **C**ontroller | Logika - prima HTTP zahtjev, vraća View | `PacijentiController.cs` |

Razor sintaksa: `@Model` čita prosljeđeni model, `@foreach`/`@if` su obični C# unutar HTML-a, `asp-for`/`asp-action` su Tag Helpers koji generiraju HTML.

## Kako pokrenuti

### 1) Prvo pokreni API iz vježbe 4
Otvori `Vjezba4_API/PacijentiSustav.sln`, pritisni F5. API mora biti aktivan na `https://localhost:7100`. Provjeri da Swagger radi.

### 2) Otvori i pokreni Web
- Otvori novi Visual Studio prozor → `Vjezba5_Web/PacijentiWeb.sln`
- F5
- Otvara se browser na `https://localhost:7200` → preusmjerava na popis pacijenata

> Ako koristiš drugi port za API, izmijeni `ApiBaseUrl` u `PacijentiWeb/appsettings.json`.

### Profi varijanta - oba projekta u istom Visual Studio
Možeš obje solution datoteke spojiti: u Vjezba5 desni klik na solution → Add → Existing Project → odaberi `Vjezba4_API/PacijentiAPI/PacijentiAPI.csproj` (i Shared). Onda postavi multiple startup projects (API i Web), F5 pokreće oboje.

## Koncepti iz vaših primjera

| Primjer | Gdje |
| --- | --- |
| `AsynchronousMembers.cs` | `ApiKlijent.cs` - svaki API poziv je async |
| `ExceptionFilters.cs` | `PacijentiController.Novi` - `catch when (ex.Message.Contains("409"))` |
| `NullableValueTypes.cs` | `DateTime?` za otpust i `int?` Id u VM |
| `ObjectAndCollectionInitializer.cs` | `new PacijentFormaVM { Id = ..., Ime = ... }` u kontroleru |
| `StringInterpolation.cs` | `$"api/pacijenti/{id}"` u ApiKlijentu |

## Što slijedi u vježbi 6

- Pretraživanje/filtriranje/sortiranje po stupcima ime, prezime, datum primanja, datum otpusta, OIB, MBO
- I prepravak na **Razor Pages** (umjesto MVC) - profesor to izričito traži u 6. vježbi
