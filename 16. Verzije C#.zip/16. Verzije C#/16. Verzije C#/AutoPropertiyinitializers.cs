public class Person
{
    public string FirstName { get; set; } = string.Empty;

    // remaining implementation removed from listing
}