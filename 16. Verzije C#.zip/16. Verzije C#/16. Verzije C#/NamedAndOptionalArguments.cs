PrintOrderDetails("Gift Shop", 31, "Red Mug");

PrintOrderDetails(orderNum: 31, productName: "Red Mug", sellerName: "Gift Shop");
PrintOrderDetails(productName: "Red Mug", sellerName: "Gift Shop", orderNum: 31);


public void ExampleMethod(int required, string optionalstr = "default string",
    int optionalint = 10)
	
anExample.ExampleMethod(3, optionalint: 4);