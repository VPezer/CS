namespace PacijentiShared
{
    // Status osiguranja koji profesor traži (obvezno + dopunsko).
    // U pravom sustavu bi se provjeravao kod HZZO-a; mi simuliramo.
    public class OsiguranjeDto
    {
        public string OIB { get; set; }
        public bool ObveznoAktivno { get; set; }
        public bool DopunskoAktivno { get; set; }
        public string Napomena { get; set; }
    }
}
