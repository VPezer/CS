namespace PacijentiShared
{
    public class DijagnozaDto
    {
        public string Sifra { get; set; }   // primarni ključ (npr. "A00")
        public string Naziv { get; set; }
    }
}
