using System;

namespace PacijentiShared
{
    // DTO = Data Transfer Object.
    // Klasa koju razmjenjuju API i klijent preko HTTP-a (JSON).
    //
    // Razlika u odnosu na vježbu 3: ovdje DODAJEMO Id (jer baza generira primarni ključ)
    // i Dijagnozu šaljemo kao DijagnozaSifra (string), ne kao cijeli objekt -
    // tako je JSON jednostavniji i šaljemo manje podataka.
    public class PacijentDto
    {
        public int Id { get; set; }                  // generira baza
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public string OIB { get; set; }
        public string MBO { get; set; }
        public string Spol { get; set; }             // "Musko" ili "Zensko"
        public DateTime DatumRodenja { get; set; }
        public DateTime DatumPrimanja { get; set; }
        public DateTime? DatumOtpusta { get; set; }  // null = aktivan
        public string DijagnozaSifra { get; set; }
        public string DijagnozaNaziv { get; set; }   // server popunjava u GET-u
    }
}
