# Vježba 4 - REST API + SQL Server + WPF klijent

> **Verzija:** .NET 10 (LTS). Tooling: Visual Studio 2022 17.12+ ili Visual Studio 2026, ili `dotnet` CLI.

## Što ova vježba radi

Sustav od **3 projekta** koji rade zajedno:

```
PacijentiSustav.sln
├── PacijentiAPI/       ← ASP.NET Core Web API (server)
├── PacijentiShared/    ← DTO klase koje dijele API i klijent
└── PacijentiWPF/       ← Ažurirani WPF klijent iz vježbe 3
```

API ima endpointe za sve što profesor traži:
- `GET /api/pacijenti` — popis svih (uz `?samoAktivni=true` za filter)
- `GET /api/pacijenti/{id}` — jedan
- `POST /api/pacijenti` — novi
- `PUT /api/pacijenti/{id}` — izmjena
- `POST /api/pacijenti/{id}/otpust` — otpust
- `GET /api/dijagnoze` — MKB-10 šifre iz baze
- `GET /api/osiguranje/{oib}` — status obveznog i dopunskog osiguranja

## Kako pokrenuti

### 1) Otvori solution
- Visual Studio 2022 → File → Open → Project/Solution → `PacijentiSustav.sln`

### 2) Provjera SQL Server LocalDB
LocalDB **dolazi automatski uz Visual Studio** (komponenta "Data storage and processing"). Provjera u Package Manager Console:
```
sqllocaldb info
```
Mora se vidjeti `MSSQLLocalDB`. Ako ne, instaliraj preko Visual Studio Installer-a.

### 3) Kreiraj bazu (Migracije)
U Visual Studiju: **Tools → NuGet Package Manager → Package Manager Console**, postaviti **Default project: PacijentiAPI** i pokrenuti:

```powershell
Add-Migration Inicijalna
Update-Database
```

> Ako se `Add-Migration` ne pojavi, prvo instaliraj globalne EF Core alate:
> `dotnet tool install --global dotnet-ef` (radi i kroz običan terminal).

To će kreirati bazu `PacijentiDB` u LocalDB-u s tablicama **Pacijenti** i **Dijagnoze** (potonja popunjena s 10 MKB-10 šifri iz seed-a).

### 4) Postavi MULTIPLE startup projects
- Desni klik na solution → **Configure Startup Projects** → **Multiple startup projects**:
  - `PacijentiAPI` → Action: **Start**
  - `PacijentiWPF` → Action: **Start**
  - `PacijentiShared` → Action: **None**
- OK

### 5) F5
Otvaraju se 2 prozora:
- **Scalar UI** u browseru (`https://localhost:7100/scalar/v1`) — moderni vizualni UI za testiranje API-ja (zamjena za Swagger UI u .NET 10). Sirovi OpenAPI dokument je na `/openapi/v1.json`.
- **WPF aplikacija** — sad više nema in-memory listu, sve ide kroz API u bazu

## Kako koristiti WPF klijenta

1. **Unos** → ispuni formu → "Spremi" → POST na API → red se pojavljuje u tablici.
2. **OIB → osiguranje**: čim makneš fokus s polja OIB, klijent automatski zove `/api/osiguranje/{oib}` i prikazuje status.
3. **Izmjena**: klikni na red u tablici → izmijeni polja → "Izmijeni" → PUT na API.
4. **Otpust**: klikni na red → "Otpusti" → POST na `/api/pacijenti/{id}/otpust`.
5. **Filter**: checkbox "Prikaži samo aktivne" → GET s `samoAktivni=true`.

## Koji koncepti iz vaših primjera

| Primjer | Gdje |
| --- | --- |
| `AsynchronousMembers.cs` (async/await, HttpClient) | `ApiKlijent.cs` — svi pozivi prema API-ju |
| `ExceptionFilters.cs` (`catch when`) | `MainWindow.xaml.cs` — različita poruka za 409 Conflict |
| `NullableValueTypes.cs` (`DateTime?`) | `DatumOtpusta` je opet nullable |
| `ObjectAndCollectionInitializer.cs` | `new PacijentDto { Ime = ..., Prezime = ... }` posvuda |
| `AutoImplementedProperties.cs` | Sve DTO/entitet klase |
| `StringInterpolation.cs` | `$"api/pacijenti/{id}/otpust"` |
| `NamedAndOptionalArguments.cs` | `DohvatiSvePacijente(samoAktivni: true)` i `[FromQuery] bool samoAktivni = false` |

## Testiranje API-ja bez WPF-a

Otvori Scalar UI (`https://localhost:7100/scalar/v1`) — vidi sve endpointe i može ih se kliknuti, popuniti i pozvati direktno. Idealno za demonstraciju profesoru.

> **Napomena o .NET 10:** Microsoft je u .NET 9 izbacio Swashbuckle (Swagger UI) iz defaultnih ASP.NET Core templatea i u .NET 10 nudi vlastiti ugrađeni `Microsoft.AspNetCore.OpenApi` paket. Koristimo ga uz **Scalar UI** — moderni vizualni klijent. Sve radi isto kao Swagger, samo izgleda ljepše i dolazi s OpenAPI 3.1 specifikacijom.

## Što sljedi u vježbi 5

Web aplikacija (ASP.NET Core MVC) koja zove **ovaj isti API** — neće više biti WPF, nego browser. API se NE MIJENJA, samo dodajemo novog "klijenta".
