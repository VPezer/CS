using System;
using System.Linq;
using System.Windows;
using PacijentiShared;
using PacijentiWPF.Servisi;

namespace PacijentiWPF
{
    public partial class MainWindow : Window
    {
        private readonly ApiKlijent _api = new ApiKlijent();
        private int? _odabraniId = null;   // Id pacijenta koji se trenutno edituje (null = novi)

        public MainWindow()
        {
            InitializeComponent();
            // Inicijalno učitavanje je async; pokrećemo ga preko Loaded eventa.
            Loaded += async (s, e) => await InicijalnoUcitavanje();
        }

        private async System.Threading.Tasks.Task InicijalnoUcitavanje()
        {
            try
            {
                cmbDijagnoza.ItemsSource = await _api.DohvatiDijagnoze();
                cmbDijagnoza.DisplayMemberPath = "Naziv";
                cmbDijagnoza.SelectedValuePath = "Sifra";
                if (cmbDijagnoza.Items.Count > 0) cmbDijagnoza.SelectedIndex = 0;

                dpDatumRodenja.SelectedDate = DateTime.Today.AddYears(-30);
                dpDatumPrimanja.SelectedDate = DateTime.Today;

                await OsvjeziTablicu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri spajanju na API: " + ex.Message,
                    "Greška", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ---------------- SPREMI (POST) ----------------
        private async void btnSpremi_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidirajFormu()) return;

            var dto = SkupiDtoIzForme();
            try
            {
                await _api.DodajPacijenta(dto);
                await OsvjeziTablicu();
                Ocisti();
            }
            // Exception filter (vidi vaš ExceptionFilters.cs) - različita poruka za 409 Conflict
            catch (System.Net.Http.HttpRequestException ex) when (ex.Message.Contains("409"))
            {
                MessageBox.Show("Pacijent s tim OIB-om već postoji.", "Greška",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška: " + ex.Message);
            }
        }

        // ---------------- IZMIJENI (PUT) ----------------
        private async void btnIzmijeni_Click(object sender, RoutedEventArgs e)
        {
            if (_odabraniId == null)
            {
                MessageBox.Show("Odaberite pacijenta u tablici.");
                return;
            }
            if (!ValidirajFormu()) return;

            var dto = SkupiDtoIzForme();
            dto.Id = _odabraniId.Value;
            try
            {
                await _api.IzmijeniPacijenta(_odabraniId.Value, dto);
                await OsvjeziTablicu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri izmjeni: " + ex.Message);
            }
        }

        // ---------------- OTPUSTI ----------------
        private async void btnOtpusti_Click(object sender, RoutedEventArgs e)
        {
            if (_odabraniId == null)
            {
                MessageBox.Show("Odaberite pacijenta u tablici.");
                return;
            }
            try
            {
                await _api.OtpustiPacijenta(_odabraniId.Value);
                await OsvjeziTablicu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška: " + ex.Message);
            }
        }

        // ---------------- NOVO ----------------
        private void btnNovo_Click(object sender, RoutedEventArgs e) => Ocisti();

        // ---------------- FILTER ----------------
        private async void chkSamoAktivni_Changed(object sender, RoutedEventArgs e)
        {
            await OsvjeziTablicu();
        }

        // ---------------- ODABIR REDA ----------------
        private void dgPacijenti_SelectionChanged(object sender,
            System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (dgPacijenti.SelectedItem is PacijentDto p)
            {
                _odabraniId = p.Id;
                txtIme.Text = p.Ime;
                txtPrezime.Text = p.Prezime;
                txtOIB.Text = p.OIB;
                txtMBO.Text = p.MBO;
                rbMusko.IsChecked = p.Spol == "Musko";
                rbZensko.IsChecked = p.Spol == "Zensko";
                dpDatumRodenja.SelectedDate = p.DatumRodenja;
                dpDatumPrimanja.SelectedDate = p.DatumPrimanja;
                dpDatumOtpusta.SelectedDate = p.DatumOtpusta;
                cmbDijagnoza.SelectedValue = p.DijagnozaSifra;
            }
        }

        // ---------------- OIB → osiguranje ----------------
        private async void txtOIB_LostFocus(object sender, RoutedEventArgs e)
        {
            if (txtOIB.Text.Length == 11 && txtOIB.Text.All(char.IsDigit))
            {
                try
                {
                    var status = await _api.DohvatiOsiguranje(txtOIB.Text);
                    lblObvezno.Text = $"Obvezno: {(status.ObveznoAktivno ? "DA" : "NE")}";
                    lblDopunsko.Text = $"Dopunsko: {(status.DopunskoAktivno ? "DA" : "NE")}";
                }
                catch { /* ignor */ }
            }
        }

        // ---------------- POMOĆNE ----------------
        private bool ValidirajFormu()
        {
            if (string.IsNullOrWhiteSpace(txtIme.Text) ||
                string.IsNullOrWhiteSpace(txtPrezime.Text))
            {
                MessageBox.Show("Ime i prezime obavezni.");
                return false;
            }
            if (txtOIB.Text.Length != 11 || !txtOIB.Text.All(char.IsDigit))
            {
                MessageBox.Show("OIB mora imati 11 znamenki.");
                return false;
            }
            if (dpDatumPrimanja.SelectedDate == null)
            {
                MessageBox.Show("Datum primanja je obavezan.");
                return false;
            }
            if (cmbDijagnoza.SelectedItem == null)
            {
                MessageBox.Show("Odaberite dijagnozu.");
                return false;
            }
            return true;
        }

        private PacijentDto SkupiDtoIzForme()
        {
            return new PacijentDto
            {
                Ime = txtIme.Text.Trim(),
                Prezime = txtPrezime.Text.Trim(),
                OIB = txtOIB.Text.Trim(),
                MBO = txtMBO.Text.Trim(),
                Spol = rbMusko.IsChecked == true ? "Musko" : "Zensko",
                DatumRodenja = dpDatumRodenja.SelectedDate ?? DateTime.Today,
                DatumPrimanja = dpDatumPrimanja.SelectedDate.Value,
                DatumOtpusta = dpDatumOtpusta.SelectedDate,
                DijagnozaSifra = (string)cmbDijagnoza.SelectedValue
            };
        }

        private async System.Threading.Tasks.Task OsvjeziTablicu()
        {
            try
            {
                var lista = await _api.DohvatiSvePacijente(chkSamoAktivni.IsChecked == true);
                dgPacijenti.ItemsSource = null;
                dgPacijenti.ItemsSource = lista;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Greška pri dohvatu: " + ex.Message);
            }
        }

        private void Ocisti()
        {
            _odabraniId = null;
            txtIme.Clear(); txtPrezime.Clear(); txtOIB.Clear(); txtMBO.Clear();
            rbMusko.IsChecked = true;
            dpDatumRodenja.SelectedDate = DateTime.Today.AddYears(-30);
            dpDatumPrimanja.SelectedDate = DateTime.Today;
            dpDatumOtpusta.SelectedDate = null;
            if (cmbDijagnoza.Items.Count > 0) cmbDijagnoza.SelectedIndex = 0;
            lblObvezno.Text = "Obvezno: -";
            lblDopunsko.Text = "Dopunsko: -";
            dgPacijenti.SelectedItem = null;
        }
    }
}
