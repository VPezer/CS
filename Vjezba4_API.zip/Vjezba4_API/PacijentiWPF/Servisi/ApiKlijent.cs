using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using PacijentiShared;

namespace PacijentiWPF.Servisi
{
    // Wrapper oko HttpClient-a koji izlaže "lijepe" metode za pozive na API.
    //
    // Sve metode su async (vidi vaš AsynchronousMembers.cs primjer) - HTTP pozivi
    // ne smiju blokirati UI thread. await pauzira metodu dok server ne odgovori,
    // a UI ostaje responzivan.
    public class ApiKlijent
    {
        private readonly HttpClient _http;

        public ApiKlijent(string baseUrl = "https://localhost:7100/")
        {
            _http = new HttpClient { BaseAddress = new System.Uri(baseUrl) };
        }

        // ---- PACIJENTI ----
        public async Task<List<PacijentDto>> DohvatiSvePacijente(bool samoAktivni = false)
        {
            var url = $"api/pacijenti?samoAktivni={samoAktivni}";
            return await _http.GetFromJsonAsync<List<PacijentDto>>(url);
        }

        public async Task<PacijentDto> DodajPacijenta(PacijentDto novi)
        {
            var resp = await _http.PostAsJsonAsync("api/pacijenti", novi);
            resp.EnsureSuccessStatusCode();
            return await resp.Content.ReadFromJsonAsync<PacijentDto>();
        }

        public async Task IzmijeniPacijenta(int id, PacijentDto izmjenjeni)
        {
            var resp = await _http.PutAsJsonAsync($"api/pacijenti/{id}", izmjenjeni);
            resp.EnsureSuccessStatusCode();
        }

        public async Task OtpustiPacijenta(int id)
        {
            var resp = await _http.PostAsync($"api/pacijenti/{id}/otpust", null);
            resp.EnsureSuccessStatusCode();
        }

        // ---- DIJAGNOZE ----
        public async Task<List<DijagnozaDto>> DohvatiDijagnoze()
        {
            return await _http.GetFromJsonAsync<List<DijagnozaDto>>("api/dijagnoze");
        }

        // ---- OSIGURANJE ----
        public async Task<OsiguranjeDto> DohvatiOsiguranje(string oib)
        {
            return await _http.GetFromJsonAsync<OsiguranjeDto>($"api/osiguranje/{oib}");
        }
    }
}
