using System.Windows;
namespace PacijentiWPF { public partial class App : Application { } }
