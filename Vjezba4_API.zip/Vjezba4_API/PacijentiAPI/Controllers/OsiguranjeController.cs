using Microsoft.AspNetCore.Mvc;
using PacijentiAPI.Servisi;

namespace PacijentiAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OsiguranjeController : ControllerBase
    {
        private readonly OsiguranjeServis _servis;
        public OsiguranjeController(OsiguranjeServis servis) { _servis = servis; }

        // GET /api/osiguranje/12345678901
        [HttpGet("{oib}")]
        public IActionResult Provjeri(string oib)
        {
            var status = _servis.ProvjeriStatus(oib);
            return Ok(status);
        }
    }
}
