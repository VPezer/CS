using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PacijentiAPI.Podaci;
using PacijentiShared;

namespace PacijentiAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DijagnozeController : ControllerBase
    {
        private readonly PacijentiContext _db;
        public DijagnozeController(PacijentiContext db) { _db = db; }

        // GET /api/dijagnoze
        [HttpGet]
        public async Task<ActionResult> GetSve()
        {
            var list = await _db.Dijagnoze
                .OrderBy(d => d.Sifra)
                .Select(d => new DijagnozaDto { Sifra = d.Sifra, Naziv = d.Naziv })
                .ToListAsync();
            return Ok(list);
        }
    }
}
