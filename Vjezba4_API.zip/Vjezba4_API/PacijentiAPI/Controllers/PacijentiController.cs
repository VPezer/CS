using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PacijentiAPI.Entiteti;
using PacijentiAPI.Podaci;
using PacijentiShared;

namespace PacijentiAPI.Controllers
{
    // [ApiController] aktivira automatsku validaciju i 400 odgovore.
    // Route "api/pacijenti" - URL će biti https://localhost:.../api/pacijenti
    [ApiController]
    [Route("api/[controller]")]
    public class PacijentiController : ControllerBase
    {
        private readonly PacijentiContext _db;

        // DbContext nam ASP.NET Core "ubacuje" preko Dependency Injection -
        // konstruktor uzima context, ne zovemo new ručno.
        public PacijentiController(PacijentiContext db)
        {
            _db = db;
        }

        // -------- GET /api/pacijenti?samoAktivni=true --------
        // Vraća sve pacijente; opcionalni query param filtrira samo aktivne.
        // Koristimo Named/Optional Arguments stil (vidi vaš NamedAndOptionalArguments.cs).
        [HttpGet]
        public async Task<ActionResult> GetSve([FromQuery] bool samoAktivni = false)
        {
            var query = _db.Pacijenti.Include(p => p.Dijagnoza).AsQueryable();

            if (samoAktivni)
                query = query.Where(p => p.DatumOtpusta == null);

            // Pretvorimo entitete u DTO-ove prije slanja klijentu.
            var rezultat = await query
                .Select(p => new PacijentDto
                {
                    Id = p.Id,
                    Ime = p.Ime,
                    Prezime = p.Prezime,
                    OIB = p.OIB,
                    MBO = p.MBO,
                    Spol = p.Spol,
                    DatumRodenja = p.DatumRodenja,
                    DatumPrimanja = p.DatumPrimanja,
                    DatumOtpusta = p.DatumOtpusta,
                    DijagnozaSifra = p.DijagnozaSifra,
                    DijagnozaNaziv = p.Dijagnoza.Naziv
                })
                .ToListAsync();

            return Ok(rezultat);
        }

        // -------- GET /api/pacijenti/5 --------
        [HttpGet("{id}")]
        public async Task<ActionResult<PacijentDto>> GetJedan(int id)
        {
            var p = await _db.Pacijenti.Include(x => x.Dijagnoza)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (p == null) return NotFound();

            return new PacijentDto
            {
                Id = p.Id, Ime = p.Ime, Prezime = p.Prezime, OIB = p.OIB, MBO = p.MBO,
                Spol = p.Spol, DatumRodenja = p.DatumRodenja,
                DatumPrimanja = p.DatumPrimanja, DatumOtpusta = p.DatumOtpusta,
                DijagnozaSifra = p.DijagnozaSifra, DijagnozaNaziv = p.Dijagnoza?.Naziv
            };
        }

        // -------- POST /api/pacijenti -------- (NOVI PACIJENT)
        [HttpPost]
        public async Task<ActionResult<PacijentDto>> Kreiraj([FromBody] PacijentDto dto)
        {
            if (await _db.Pacijenti.AnyAsync(p => p.OIB == dto.OIB))
                return Conflict("Pacijent s tim OIB-om već postoji.");

            var entitet = new PacijentEntitet
            {
                Ime = dto.Ime,
                Prezime = dto.Prezime,
                OIB = dto.OIB,
                MBO = dto.MBO,
                Spol = dto.Spol,
                DatumRodenja = dto.DatumRodenja,
                DatumPrimanja = dto.DatumPrimanja,
                DatumOtpusta = dto.DatumOtpusta,
                DijagnozaSifra = dto.DijagnozaSifra
            };

            _db.Pacijenti.Add(entitet);
            await _db.SaveChangesAsync();

            dto.Id = entitet.Id;
            return CreatedAtAction(nameof(GetJedan), new { id = entitet.Id }, dto);
        }

        // -------- PUT /api/pacijenti/5 -------- (IZMJENA)
        [HttpPut("{id}")]
        public async Task<IActionResult> Izmijeni(int id, [FromBody] PacijentDto dto)
        {
            var entitet = await _db.Pacijenti.FindAsync(id);
            if (entitet == null) return NotFound();

            entitet.Ime = dto.Ime;
            entitet.Prezime = dto.Prezime;
            entitet.OIB = dto.OIB;
            entitet.MBO = dto.MBO;
            entitet.Spol = dto.Spol;
            entitet.DatumRodenja = dto.DatumRodenja;
            entitet.DatumPrimanja = dto.DatumPrimanja;
            entitet.DatumOtpusta = dto.DatumOtpusta;
            entitet.DijagnozaSifra = dto.DijagnozaSifra;

            await _db.SaveChangesAsync();
            return NoContent();
        }

        // -------- POST /api/pacijenti/5/otpust -------- (OTPUST)
        [HttpPost("{id}/otpust")]
        public async Task<IActionResult> Otpusti(int id)
        {
            var entitet = await _db.Pacijenti.FindAsync(id);
            if (entitet == null) return NotFound();

            if (entitet.DatumOtpusta != null)
                return BadRequest("Pacijent je već otpušten.");

            entitet.DatumOtpusta = System.DateTime.Today;
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
