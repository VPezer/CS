using PacijentiShared;

namespace PacijentiAPI.Servisi
{
    // Simulacija provjere statusa osiguranja. U pravom sustavu bi se zvao HZZO web service.
    // Deterministički rezultat baziran na zadnjoj znamenki OIB-a - dovoljno za predaju vježbe.
    public class OsiguranjeServis
    {
        public OsiguranjeDto ProvjeriStatus(string oib)
        {
            if (string.IsNullOrWhiteSpace(oib) || oib.Length != 11)
            {
                return new OsiguranjeDto
                {
                    OIB = oib,
                    ObveznoAktivno = false,
                    DopunskoAktivno = false,
                    Napomena = "Neispravan OIB"
                };
            }

            // Pretvori zadnju znamenku u broj i koristi je za pseudo-status.
            int zadnja = oib[10] - '0';

            return new OsiguranjeDto
            {
                OIB = oib,
                ObveznoAktivno = zadnja % 2 == 0,            // parna = obvezno aktivno
                DopunskoAktivno = zadnja >= 5,               // ≥5 = ima dopunsko
                Napomena = "Status simuliran (nije pravi HZZO upit)"
            };
        }
    }
}
