using Microsoft.EntityFrameworkCore;
using PacijentiAPI.Entiteti;

namespace PacijentiAPI.Podaci
{
    // DbContext predstavlja sjednicu s bazom. Kroz njega EF Core radi SELECT/INSERT/UPDATE/DELETE.
    public class PacijentiContext : DbContext
    {
        public PacijentiContext(DbContextOptions<PacijentiContext> options)
            : base(options) { }

        // Svaki DbSet<T> = jedna tablica
        public DbSet<PacijentEntitet> Pacijenti { get; set; }
        public DbSet<DijagnozaEntitet> Dijagnoze { get; set; }

        // OnModelCreating se zove jednom pri startu i tu možemo:
        //   - Definirati dodatne constraint-e (unique, indexe)
        //   - Ubaciti seed podatke (početne MKB-10 dijagnoze)
        protected override void OnModelCreating(ModelBuilder mb)
        {
            // OIB mora biti jedinstven
            mb.Entity<PacijentEntitet>()
                .HasIndex(p => p.OIB)
                .IsUnique();

            // 10 osnovnih MKB-10 dijagnoza (profesor traži min. 10)
            mb.Entity<DijagnozaEntitet>().HasData(
                new DijagnozaEntitet { Sifra = "A00", Naziv = "Kolera" },
                new DijagnozaEntitet { Sifra = "A01", Naziv = "Trbušni tifus i paratifus" },
                new DijagnozaEntitet { Sifra = "B01", Naziv = "Vodene kozice (varicella)" },
                new DijagnozaEntitet { Sifra = "E11", Naziv = "Dijabetes melitus tip 2" },
                new DijagnozaEntitet { Sifra = "I10", Naziv = "Esencijalna hipertenzija" },
                new DijagnozaEntitet { Sifra = "J18", Naziv = "Upala pluća, uzročnik nespecificiran" },
                new DijagnozaEntitet { Sifra = "J45", Naziv = "Astma" },
                new DijagnozaEntitet { Sifra = "K35", Naziv = "Akutni apendicitis" },
                new DijagnozaEntitet { Sifra = "M54", Naziv = "Bol u leđima" },
                new DijagnozaEntitet { Sifra = "R51", Naziv = "Glavobolja" }
            );

            base.OnModelCreating(mb);
        }
    }
}
