using Microsoft.EntityFrameworkCore;
using PacijentiAPI.Podaci;
using PacijentiAPI.Servisi;
using Scalar.AspNetCore;

// Minimal hosting model iz .NET 6+ - sve u jednom Program.cs-u (nema više Startup klase).
var builder = WebApplication.CreateBuilder(args);

// --- 1. Registracija servisa u DI kontejner ---
builder.Services.AddControllers();
// .NET 10: ugrađeni OpenAPI (zamjena za Swashbuckle/Swagger).
builder.Services.AddOpenApi();

// EF Core + SQL Server LocalDB; connection string se čita iz appsettings.json
builder.Services.AddDbContext<PacijentiContext>(opt =>
    opt.UseSqlServer(builder.Configuration.GetConnectionString("PacijentiDB")));

builder.Services.AddSingleton<OsiguranjeServis>();

// CORS - da WPF i Web aplikacija mogu zvati API s druge adrese
builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader()));

// --- 2. Build i HTTP pipeline ---
var app = builder.Build();

// Automatski apply migracija + seed pri startu (super za development)
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<PacijentiContext>();
    db.Database.Migrate();
}

if (app.Environment.IsDevelopment())
{
    // /openapi/v1.json - servira generirani OpenAPI 3.1 dokument
    app.MapOpenApi();
    // /scalar/v1 - moderni vizualni UI za testiranje endpointa (zamjena za Swagger UI)
    app.MapScalarApiReference();
}

app.UseCors();
app.UseAuthorization();
app.MapControllers();

app.Run();
