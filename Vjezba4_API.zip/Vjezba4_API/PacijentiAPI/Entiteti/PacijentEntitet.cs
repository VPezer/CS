using System;
using System.ComponentModel.DataAnnotations;

namespace PacijentiAPI.Entiteti
{
    // Entitet = klasa koju Entity Framework Core mapira na tablicu u bazi.
    // Razdvajamo je od DTO-a (PacijentDto) iz dva razloga:
    //  1) Entitet ima EF Core specifične stvari (Navigation properties, atributi za bazu).
    //  2) DTO putuje preko HTTP-a i ne smije nositi nepotrebne informacije.
    //
    // [Required], [MaxLength] su Data Annotations - EF Core ih čita pri kreiranju tablica.
    public class PacijentEntitet
    {
        public int Id { get; set; }   // primarni ključ, EF generira auto-increment

        [Required, MaxLength(50)]
        public string Ime { get; set; }

        [Required, MaxLength(50)]
        public string Prezime { get; set; }

        [Required, MaxLength(11)]
        public string OIB { get; set; }

        [MaxLength(9)]
        public string MBO { get; set; }

        [Required, MaxLength(10)]
        public string Spol { get; set; }   // "Musko" ili "Zensko" (kao string radi jednostavnosti)

        public DateTime DatumRodenja { get; set; }
        public DateTime DatumPrimanja { get; set; }
        public DateTime? DatumOtpusta { get; set; }

        // Foreign key prema dijagnozi
        [MaxLength(10)]
        public string DijagnozaSifra { get; set; }
        public DijagnozaEntitet Dijagnoza { get; set; }   // navigation property
    }
}
