using System.ComponentModel.DataAnnotations;

namespace PacijentiAPI.Entiteti
{
    public class DijagnozaEntitet
    {
        [Key, MaxLength(10)]
        public string Sifra { get; set; }   // npr. "A00" - prirodni primarni ključ

        [Required, MaxLength(200)]
        public string Naziv { get; set; }
    }
}
